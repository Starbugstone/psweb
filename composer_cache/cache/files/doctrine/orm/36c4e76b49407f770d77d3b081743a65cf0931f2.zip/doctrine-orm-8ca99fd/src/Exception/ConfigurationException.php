<?php

declare(strict_types=1);

namespace Doctrine\ORM\Exception;

interface ConfigurationException extends ORMException
{
}
